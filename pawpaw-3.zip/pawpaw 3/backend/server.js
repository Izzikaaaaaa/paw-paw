require('dotenv').config();
const express = require('express');
const cors = require('cors');

const petsRouter = require('./routes/pets');
const servicesRouter = require('./routes/services');
const appointmentsRouter = require('./routes/appointments');
const mealsRouter = require('./routes/meals');
const chatRouter = require('./routes/chat');
const usersRouter = require('./routes/users');

const app = express();
const PORT = process.env.PORT || 4000;

app.use(cors());
app.use(express.json({ limit: '5mb' }));

app.get('/api/health', (req, res) => res.json({ status: 'ok', service: 'pawpaw-backend' }));

app.use('/api/pets', petsRouter);
app.use('/api/services', servicesRouter);
app.use('/api/appointments', appointmentsRouter);
app.use('/api/meals', mealsRouter);
app.use('/api/chat', chatRouter);
app.use('/api/users', usersRouter);

app.use((req, res) => res.status(404).json({ error: 'Not found' }));

app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).json({ error: 'Internal server error' });
});

app.listen(PORT, () => {
  console.log(`🐾 PawPaw backend running at http://localhost:${PORT}`);
});
