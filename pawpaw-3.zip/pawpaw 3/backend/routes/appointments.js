const express = require('express');
const { randomUUID } = require('crypto');
const db = require('../db/database');

const router = express.Router();
const DEMO_USER = 'ishika';

// GET all appointments (joined with pet name)
router.get('/', (req, res) => {
  const appts = db.prepare(`
    SELECT a.*, p.name as pet_name, p.photo as pet_photo
    FROM appointments a
    LEFT JOIN pets p ON a.pet_id = p.id
    WHERE a.user_id = ?
    ORDER BY a.date ASC, a.time ASC
  `).all(DEMO_USER);
  res.json(appts);
});

// Available slots for a given date (mock business logic — some slots randomly booked)
router.get('/slots', (req, res) => {
  const { date } = req.query;
  const allSlots = ['9:00 AM', '10:00 AM', '11:00 AM', '1:00 PM', '2:00 PM', '3:00 PM', '4:00 PM', '5:00 PM'];
  const booked = db.prepare('SELECT time FROM appointments WHERE date = ?').all(date).map(r => r.time);
  const providers = ['Johnson', 'Brown', 'White', 'Chen'];
  const slots = allSlots.map((time, i) => ({
    time,
    available: !booked.includes(time),
    provider: providers[i % providers.length]
  }));
  res.json(slots);
});

// CREATE appointment
router.post('/', (req, res) => {
  const { pet_id, service_id, title, provider, date, time, location_type, notes } = req.body;
  if (!title || !date || !time) return res.status(400).json({ error: 'title, date and time are required' });

  const id = randomUUID();
  db.prepare(`INSERT INTO appointments (id,user_id,pet_id,service_id,title,provider,date,time,location_type,status,notes)
    VALUES (?,?,?,?,?,?,?,?,?,?,?)`)
    .run(id, DEMO_USER, pet_id || null, service_id || null, title, provider || 'TBD', date, time, location_type || 'In-Person', 'confirmed', notes || '');

  const appt = db.prepare(`
    SELECT a.*, p.name as pet_name, p.photo as pet_photo
    FROM appointments a LEFT JOIN pets p ON a.pet_id = p.id
    WHERE a.id = ?`).get(id);
  res.status(201).json(appt);
});

// UPDATE appointment (e.g. status change / reschedule)
router.put('/:id', (req, res) => {
  const existing = db.prepare('SELECT * FROM appointments WHERE id = ?').get(req.params.id);
  if (!existing) return res.status(404).json({ error: 'Appointment not found' });

  const fields = ['title', 'provider', 'date', 'time', 'location_type', 'status', 'notes'];
  const updates = {};
  fields.forEach(f => { if (req.body[f] !== undefined) updates[f] = req.body[f]; });
  const setClause = Object.keys(updates).map(k => `${k} = @${k}`).join(', ');
  if (setClause) {
    db.prepare(`UPDATE appointments SET ${setClause} WHERE id = @id`).run({ ...updates, id: req.params.id });
  }
  const appt = db.prepare(`
    SELECT a.*, p.name as pet_name, p.photo as pet_photo
    FROM appointments a LEFT JOIN pets p ON a.pet_id = p.id
    WHERE a.id = ?`).get(req.params.id);
  res.json(appt);
});

// DELETE / cancel appointment
router.delete('/:id', (req, res) => {
  const existing = db.prepare('SELECT * FROM appointments WHERE id = ?').get(req.params.id);
  if (!existing) return res.status(404).json({ error: 'Appointment not found' });
  db.prepare('DELETE FROM appointments WHERE id = ?').run(req.params.id);
  res.json({ success: true });
});

module.exports = router;
