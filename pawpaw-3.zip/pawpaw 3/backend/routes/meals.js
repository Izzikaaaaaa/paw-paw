const express = require('express');
const { randomUUID } = require('crypto');
const db = require('../db/database');

const router = express.Router();

// GET meals for a pet
router.get('/:petId', (req, res) => {
  const meals = db.prepare('SELECT * FROM meals WHERE pet_id = ? ORDER BY logged_at DESC').all(req.params.petId);
  res.json(meals);
});

// LOG a meal
router.post('/:petId', (req, res) => {
  const { food, amount, notes } = req.body;
  if (!food) return res.status(400).json({ error: 'Food is required' });
  const id = randomUUID();
  const logged_at = new Date().toISOString();
  db.prepare('INSERT INTO meals (id, pet_id, food, amount, logged_at, notes) VALUES (?,?,?,?,?,?)')
    .run(id, req.params.petId, food, amount || '', logged_at, notes || '');
  const meal = db.prepare('SELECT * FROM meals WHERE id = ?').get(id);
  res.status(201).json(meal);
});

// DELETE a meal entry
router.delete('/entry/:id', (req, res) => {
  db.prepare('DELETE FROM meals WHERE id = ?').run(req.params.id);
  res.json({ success: true });
});

module.exports = router;
