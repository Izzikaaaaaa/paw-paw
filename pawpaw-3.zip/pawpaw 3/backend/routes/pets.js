const express = require('express');
const { randomUUID } = require('crypto');
const db = require('../db/database');

const router = express.Router();
const DEMO_USER = 'ishika';

function serializePet(p) {
  return { ...p, traits: p.traits ? JSON.parse(p.traits) : [] };
}

// GET all pets for the (demo) user
router.get('/', (req, res) => {
  const pets = db.prepare('SELECT * FROM pets WHERE user_id = ?').all(DEMO_USER);
  res.json(pets.map(serializePet));
});

// GET single pet
router.get('/:id', (req, res) => {
  const pet = db.prepare('SELECT * FROM pets WHERE id = ?').get(req.params.id);
  if (!pet) return res.status(404).json({ error: 'Pet not found' });
  res.json(serializePet(pet));
});

// CREATE pet
router.post('/', (req, res) => {
  const { name, breed, gender, age_years, weight_kg, photo, traits, favorite_food } = req.body;
  if (!name) return res.status(400).json({ error: 'Name is required' });

  const id = randomUUID();
  db.prepare(`INSERT INTO pets
    (id,user_id,name,breed,gender,age_years,weight_kg,photo,traits,favorite_food,microchip,vaccinations_current,next_vaccination)
    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)`)
    .run(
      id, DEMO_USER, name, breed || '', gender || '', age_years || 0, weight_kg || 0,
      photo || '', JSON.stringify(traits || []), favorite_food || '',
      'US-' + Math.floor(100000000 + Math.random() * 900000000), 0, null
    );

  const pet = db.prepare('SELECT * FROM pets WHERE id = ?').get(id);
  res.status(201).json(serializePet(pet));
});

// UPDATE pet
router.put('/:id', (req, res) => {
  const existing = db.prepare('SELECT * FROM pets WHERE id = ?').get(req.params.id);
  if (!existing) return res.status(404).json({ error: 'Pet not found' });

  const fields = ['name', 'breed', 'gender', 'age_years', 'weight_kg', 'photo', 'favorite_food', 'microchip', 'vaccinations_current', 'next_vaccination'];
  const updates = {};
  fields.forEach(f => { if (req.body[f] !== undefined) updates[f] = req.body[f]; });
  if (req.body.traits !== undefined) updates.traits = JSON.stringify(req.body.traits);

  const setClause = Object.keys(updates).map(k => `${k} = @${k}`).join(', ');
  if (setClause) {
    db.prepare(`UPDATE pets SET ${setClause} WHERE id = @id`).run({ ...updates, id: req.params.id });
  }
  const pet = db.prepare('SELECT * FROM pets WHERE id = ?').get(req.params.id);
  res.json(serializePet(pet));
});

// DELETE pet
router.delete('/:id', (req, res) => {
  const existing = db.prepare('SELECT * FROM pets WHERE id = ?').get(req.params.id);
  if (!existing) return res.status(404).json({ error: 'Pet not found' });
  db.prepare('DELETE FROM pets WHERE id = ?').run(req.params.id);
  db.prepare('DELETE FROM meals WHERE pet_id = ?').run(req.params.id);
  res.json({ success: true });
});

module.exports = router;
