const express = require('express');
const db = require('../db/database');

const router = express.Router();
const DEMO_USER = 'ishika';

// GET all services (optionally filtered by category)
router.get('/', (req, res) => {
  const { category } = req.query;
  let services;
  if (category && category !== 'All') {
    services = db.prepare('SELECT * FROM services WHERE category = ?').all(category);
  } else {
    services = db.prepare('SELECT * FROM services').all();
  }
  const favIds = new Set(
    db.prepare('SELECT service_id FROM favorites WHERE user_id = ?').all(DEMO_USER).map(f => f.service_id)
  );
  res.json(services.map(s => ({ ...s, favorited: favIds.has(s.id) })));
});

// GET single service
router.get('/:id', (req, res) => {
  const service = db.prepare('SELECT * FROM services WHERE id = ?').get(req.params.id);
  if (!service) return res.status(404).json({ error: 'Service not found' });
  res.json(service);
});

// Toggle favorite
router.post('/:id/favorite', (req, res) => {
  const service = db.prepare('SELECT * FROM services WHERE id = ?').get(req.params.id);
  if (!service) return res.status(404).json({ error: 'Service not found' });

  const existing = db.prepare('SELECT * FROM favorites WHERE user_id = ? AND service_id = ?').get(DEMO_USER, req.params.id);
  if (existing) {
    db.prepare('DELETE FROM favorites WHERE id = ?').run(existing.id);
    return res.json({ favorited: false });
  } else {
    const { randomUUID } = require('crypto');
    db.prepare('INSERT INTO favorites (id, user_id, service_id) VALUES (?,?,?)').run(randomUUID(), DEMO_USER, req.params.id);
    return res.json({ favorited: true });
  }
});

module.exports = router;
