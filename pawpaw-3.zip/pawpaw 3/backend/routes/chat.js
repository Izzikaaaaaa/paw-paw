const express = require('express');
const { randomUUID } = require('crypto');
const db = require('../db/database');

const router = express.Router();
const DEMO_USER = 'ishika';

let openaiClient = null;
function getClient() {
  if (!process.env.OPENAI_API_KEY) return null;
  if (process.env.DEMO_MODE === 'true') return null; // skip OpenAI if demo mode enabled
  if (!openaiClient) {
    const OpenAI = require('openai');
    openaiClient = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
  }
  return openaiClient;
}

const SYSTEM_PROMPT = `You are Pawla, the warm and caring AI companion built into the PawPaw pet care app.
You play two roles for the user, blended naturally depending on what they need:
1. A knowledgeable pet-care assistant: answer questions about pet health, behavior, nutrition, training, grooming, and when to see a vet. Be practical and specific, but always tell the user to consult a licensed veterinarian for urgent, serious, or diagnostic concerns — you are not a vet and cannot diagnose conditions.
2. A gentle, emotionally supportive companion: if the user wants to vent, talk through a hard day, or just chat, listen with empathy, validate their feelings, and offer thoughtful perspective and suggestions, the way a caring, emotionally intelligent friend would. Don't be clinical or robotic.

Keep responses conversational and not overly long unless the user asks for depth. Use a warm, friendly tone with the occasional pet-related warmth (without being over the top or cheesy). Never give actual medical dosages or diagnoses for animals or humans. If a pet's life appears to be in immediate danger, tell the user clearly to contact an emergency vet right away.`;

// GET chat history
router.get('/history', (req, res) => {
  const messages = db.prepare('SELECT * FROM chat_messages WHERE user_id = ? ORDER BY created_at ASC').all(DEMO_USER);
  res.json(messages);
});

// POST a new message, get AI reply
router.post('/message', async (req, res) => {
  const { message } = req.body;
  if (!message || !message.trim()) return res.status(400).json({ error: 'Message is required' });

  const userMsgId = randomUUID();
  const now = new Date().toISOString();
  db.prepare('INSERT INTO chat_messages (id, user_id, role, content, created_at) VALUES (?,?,?,?,?)')
    .run(userMsgId, DEMO_USER, 'user', message, now);

  const client = getClient();

  if (!client) {
    // Demo mode: generate detailed, ChatGPT-like responses based on user input
    const userMsg = message.toLowerCase();
    let demoReply = "That's a great question! I'd be happy to help. Could you provide a bit more detail about what you're asking?";

    // Health & Eating
    if ((userMsg.includes('eat') || userMsg.includes('food') || userMsg.includes('appetite')) && (userMsg.includes('not') || userMsg.includes('won\'t') || userMsg.includes('refuse'))) {
      demoReply = "Loss of appetite can indicate several issues. Here's what to consider:\n\n1. **Stress or anxiety**: Changes in environment, new pets, or loud noises can suppress appetite\n2. **Dental issues**: Check for broken teeth or gum disease\n3. **Digestive problems**: Upset stomach, parasites, or food allergies\n4. **Health conditions**: Fever, infection, or other illnesses\n\nWhat I recommend: Monitor for other symptoms (lethargy, vomiting, diarrhea). If it lasts more than 24 hours or you notice other signs, contact your vet. In the meantime, try offering their favorite treats or warming their food to enhance aroma.";
    } else if (userMsg.includes('training') || userMsg.includes('teach') || userMsg.includes('command')) {
      demoReply = "Great! Here's a structured approach to training:\n\n**Basic Training Steps:**\n1. **Choose the command**: Start with simple ones like 'sit', 'stay', or 'come'\n2. **Use high-value treats**: Find what motivates your pet most\n3. **Keep sessions short**: 5-10 minutes, multiple times daily\n4. **Timing is key**: Reward immediately when they do the behavior\n5. **Stay consistent**: Use the same words and hand signals\n6. **Practice patience**: Most pets need 50-100+ repetitions to learn\n\n**Pro tips**: Train before meals when hungry, avoid loud distractions, keep it fun, and celebrate small wins. Never punish—focus on rewards instead.";
    } else if (userMsg.includes('scratch') || userMsg.includes('itching') || userMsg.includes('itchy')) {
      demoReply = "Scratching can have multiple causes. Here's what might be happening:\n\n**Common Causes:**\n1. **Fleas**: Even indoor pets can get them. Check for small black specks\n2. **Allergies**: Food allergies or environmental triggers (pollen, dust)\n3. **Dry skin**: Winter or low humidity can dry out skin\n4. **Skin infections**: Fungal or bacterial infections\n5. **Ear mites or parasites**: Especially if scratching ears\n\n**What to do:**\n- Check their skin for redness, rashes, or bumps\n- Ensure regular flea/tick prevention\n- Use a humidifier if air is dry\n- Bathe with gentle, moisturizing shampoo\n- If persistent, see your vet for diagnosis\n\nPersistent scratching for >1 week warrants a professional evaluation.";
    } else if (userMsg.includes('groom') || userMsg.includes('brush') || userMsg.includes('bath') || userMsg.includes('fur')) {
      demoReply = "Grooming is essential for health and bonding! Here's a complete guide:\n\n**Brushing:**\n- Short-haired pets: 2-3 times weekly\n- Long-haired pets: Daily to prevent matting\n- Reduces shedding and keeps coat healthy\n\n**Bathing:**\n- Most pets: Every 4-12 weeks (depends on breed & lifestyle)\n- Use lukewarm water and pet-specific shampoo\n- Be gentle around eyes and ears\n- Towel dry thoroughly\n\n**Nail Trimming:**\n- Every 3-4 weeks if you hear clicking on floors\n- Use proper pet nail clippers\n- Or ask your groomer\n\n**Ear & Dental Care:**\n- Clean ears weekly, especially floppy-eared breeds\n- Brush teeth daily if possible, at least 3x weekly\n\nRegular grooming helps you spot skin issues early and keeps your pet comfortable.";
    } else if (userMsg.includes('behavior') || userMsg.includes('aggressive') || userMsg.includes('anxiety') || userMsg.includes('bark')) {
      demoReply = "Behavioral issues need patience and consistency. Here's how to address them:\n\n**For Excessive Barking:**\n- Identify triggers (boredom, anxiety, alerts)\n- Provide mental stimulation and exercise\n- Don't reward barking with attention\n- Train the 'quiet' command\n- Consider white noise if noise-triggered\n\n**For Anxiety/Stress:**\n- Create a safe space (crate, room)\n- Regular exercise and playtime\n- Calming supplements (consult vet)\n- Gradual desensitization to triggers\n- Never force interaction\n\n**For Aggression:**\n- Don't punish (worsens behavior)\n- See a professional trainer/behaviorist\n- Manage the environment to prevent triggers\n- Use positive reinforcement for calm behavior\n\nBehavioral changes = potential health issue. Get a vet checkup first. For serious aggression, consult a certified behaviorist.";
    } else if (userMsg.includes('age') || userMsg.includes('old') || userMsg.includes('senior') || userMsg.includes('puppy') || userMsg.includes('kitten')) {
      demoReply = "Pet care varies by life stage! Here's what to focus on:\n\n**Puppies/Kittens (0-1 year):**\n- Frequent meals (3-4x daily)\n- Vaccinations and deworming\n- Early socialization and training\n- Play and exercise (age-appropriate)\n\n**Adults (1-7 years):**\n- 1-2 meals daily\n- Regular exercise and mental stimulation\n- Annual vet checkups\n- Dental care\n\n**Seniors (7+ years):**\n- Softer food if dental issues\n- More frequent vet visits (every 6 months)\n- Joint support and lower-impact exercise\n- Watch for pain, confusion, or appetite changes\n- Keep routine stable\n\nAdjust diet, activity, and care based on your pet's age and health status. Ask your vet for age-specific recommendations.";
    } else if (userMsg.includes('vet') || userMsg.includes('sick') || userMsg.includes('ill') || userMsg.includes('emergency')) {
      demoReply = "Knowing when to see a vet is crucial. Here's a guide:\n\n**Routine Vet Care:**\n- Annual checkup for young, healthy pets\n- Every 6 months for seniors (7+)\n- Vaccinations and preventive care\n- Dental cleanings\n\n**When to Call Your Vet:**\n- Loss of appetite for >24 hours\n- Vomiting or diarrhea lasting >1 day\n- Lethargy or behavior changes\n- Limping or signs of pain\n- Excessive scratching or skin issues\n- Difficulty breathing\n\n**When to Go to Emergency:**\n- Unable to urinate or defecate\n- Severe bleeding\n- Difficulty breathing\n- Unresponsiveness\n- Suspected poisoning\n- Severe trauma\n- Signs of choking\n\nIt's better to call and ask than wait. Your vet can advise over the phone if it's urgent. Trust your instincts—you know your pet best!";
    } else if (userMsg.includes('stress') || userMsg.includes('overwhelm') || userMsg.includes('difficult') || userMsg.includes('tired') || userMsg.includes('hard')) {
      demoReply = "Pet care can definitely feel overwhelming sometimes, and that's completely valid. Here's some perspective:\n\n**Remember:**\n- You don't need to be perfect—consistency matters more\n- Small steps count (even 10 minutes of play helps)\n- It's okay to ask for help (family, friends, trainers)\n- Your effort shows your pet how much you care\n- Self-care helps you be a better pet parent\n\n**Practical tips:**\n- Break big tasks into smaller ones\n- Set realistic routines you can maintain\n- Don't compare to others (everyone struggles)\n- Celebrate what you ARE doing right\n- Consider professional help if needed (trainer, behaviorist)\n\nYour pet loves you for trying. Take breaks when needed, reach out for support, and remember that loving your pet is what matters most. 💕 What's the most challenging part right now?";
    } else if (userMsg.includes('appointment') || userMsg.includes('book') || userMsg.includes('schedule')) {
      demoReply = "Great thinking ahead! Here's how to manage pet appointments:\n\n**Scheduling.**\n- Annual checkup: Once yearly (twice for seniors)\n- Vaccinations: As recommended by your vet\n- Dental: At least annual cleaning\n- Emergency: ASAP for urgent issues\n\n**Tips:**\n- Book during slower times if your pet is anxious\n- Bring medical history and list of concerns\n- Ask about preventive care options\n- Keep records for reference\n- Set phone reminders\n\nYou can book appointments right here in the PawPaw app! Just head to the Appointments section and select your pet, date, and service. This keeps everything organized in one place.";
    } else {
      const detailedResponses = [
        "I'd love to help more specifically! Could you tell me: Is this about health, behavior, training, grooming, or something else? The more details, the better advice I can give.",
        "That's an interesting question about pet care. To give you the best answer, could you share: What species of pet do you have, and what specifically are you dealing with?",
        "I want to make sure I give you accurate, helpful advice. Could you elaborate a bit more on your situation? What's happening, and what have you tried so far?",
        "Your question is important! Pets vary a lot by breed and age. Tell me more about your specific pet and what you're trying to accomplish.",
      ];
      demoReply = detailedResponses[Math.floor(Math.random() * detailedResponses.length)];
    }

    const aiMsgId = randomUUID();
    const aiNow = new Date().toISOString();
    db.prepare('INSERT INTO chat_messages (id, user_id, role, content, created_at) VALUES (?,?,?,?,?)')
      .run(aiMsgId, DEMO_USER, 'assistant', demoReply, aiNow);
    return res.json({ id: aiMsgId, role: 'assistant', content: demoReply, created_at: aiNow });
  }

  try {
    const history = db.prepare('SELECT role, content FROM chat_messages WHERE user_id = ? ORDER BY created_at ASC').all(DEMO_USER);
    const recent = history.slice(-20); // limit context

    const completion = await client.chat.completions.create({
      model: 'gpt-4o-mini',
      messages: [
        { role: 'system', content: SYSTEM_PROMPT },
        ...recent.map(m => ({ role: m.role, content: m.content }))
      ],
      temperature: 0.8,
      max_tokens: 600
    });

    const reply = completion.choices[0]?.message?.content?.trim() || "I'm here, but I had trouble forming a reply — could you try again?";
    const aiMsgId = randomUUID();
    const aiNow = new Date().toISOString();
    db.prepare('INSERT INTO chat_messages (id, user_id, role, content, created_at) VALUES (?,?,?,?,?)')
      .run(aiMsgId, DEMO_USER, 'assistant', reply, aiNow);

    res.json({ id: aiMsgId, role: 'assistant', content: reply, created_at: aiNow });
  } catch (err) {
    console.error('OpenAI error:', err.message);
    res.status(500).json({ error: 'AI assistant is temporarily unavailable. Please check your OpenAI API key and try again.' });
  }
});

// Clear chat history
router.delete('/history', (req, res) => {
  db.prepare('DELETE FROM chat_messages WHERE user_id = ?').run(DEMO_USER);
  res.json({ success: true });
});

module.exports = router;
