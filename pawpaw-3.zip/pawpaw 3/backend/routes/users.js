const express = require('express');
const db = require('../db/database');

const router = express.Router();
const DEMO_USER = 'ishika';

router.get('/me', (req, res) => {
  const user = db.prepare('SELECT * FROM users WHERE id = ?').get(DEMO_USER);
  if (!user) return res.status(404).json({ error: 'User not found' });
  res.json(user);
});

router.put('/me', (req, res) => {
  const { name, avatar } = req.body;
  const updates = {};
  if (name !== undefined) updates.name = name;
  if (avatar !== undefined) updates.avatar = avatar;
  const setClause = Object.keys(updates).map(k => `${k} = @${k}`).join(', ');
  if (setClause) {
    db.prepare(`UPDATE users SET ${setClause} WHERE id = @id`).run({ ...updates, id: DEMO_USER });
  }
  const user = db.prepare('SELECT * FROM users WHERE id = ?').get(DEMO_USER);
  res.json(user);
});

module.exports = router;
