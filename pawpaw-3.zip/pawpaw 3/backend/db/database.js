const Database = require('better-sqlite3');
const path = require('path');
const { randomUUID } = require('crypto');

const db = new Database(path.join(__dirname, 'pawpaw.db'));
db.pragma('journal_mode = WAL');

db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  email TEXT UNIQUE NOT NULL,
  avatar TEXT
);

CREATE TABLE IF NOT EXISTS pets (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL,
  name TEXT NOT NULL,
  breed TEXT,
  gender TEXT,
  age_years REAL,
  weight_kg REAL,
  photo TEXT,
  traits TEXT,
  favorite_food TEXT,
  microchip TEXT,
  vaccinations_current INTEGER DEFAULT 1,
  next_vaccination TEXT,
  FOREIGN KEY(user_id) REFERENCES users(id)
);

CREATE TABLE IF NOT EXISTS services (
  id TEXT PRIMARY KEY,
  category TEXT NOT NULL,
  title TEXT NOT NULL,
  description TEXT,
  price TEXT,
  duration TEXT,
  distance TEXT,
  rating REAL,
  review_count INTEGER,
  image TEXT
);

CREATE TABLE IF NOT EXISTS appointments (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL,
  pet_id TEXT,
  service_id TEXT,
  title TEXT NOT NULL,
  provider TEXT,
  date TEXT NOT NULL,
  time TEXT NOT NULL,
  location_type TEXT DEFAULT 'In-Person',
  status TEXT DEFAULT 'pending',
  notes TEXT,
  FOREIGN KEY(user_id) REFERENCES users(id),
  FOREIGN KEY(pet_id) REFERENCES pets(id)
);

CREATE TABLE IF NOT EXISTS favorites (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL,
  service_id TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS meals (
  id TEXT PRIMARY KEY,
  pet_id TEXT NOT NULL,
  food TEXT NOT NULL,
  amount TEXT,
  logged_at TEXT NOT NULL,
  notes TEXT
);

CREATE TABLE IF NOT EXISTS chat_messages (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL,
  role TEXT NOT NULL,
  content TEXT NOT NULL,
  created_at TEXT NOT NULL
);
`);

// Seed default demo user + data if empty
const userCount = db.prepare('SELECT COUNT(*) AS c FROM users').get().c;
if (userCount === 0) {
    const userId = 'ishika';
    db.prepare(`INSERT INTO users (id, name, email, avatar) VALUES (?, ?, ?, ?)`)
      .run(userId, 'Ishika', 'ishika@example.com', 'I');

  const pets = [
    {
      id: randomUUID(),
      user_id: userId,
      name: 'Max',
      breed: 'Golden Retriever',
      gender: 'Male',
      age_years: 3,
      weight_kg: 32,
      photo: '',
      traits: JSON.stringify(['Playful', 'Friendly', 'Energetic']),
      favorite_food: 'Chicken & Rice',
      microchip: 'US-123456789',
      vaccinations_current: 1,
      next_vaccination: '2026-06-15'
    },
    {
      id: randomUUID(),
      user_id: userId,
      name: 'Luna',
      breed: 'Persian',
      gender: 'Female',
      age_years: 2,
      weight_kg: 4.5,
      photo: '',
      traits: JSON.stringify(['Calm', 'Curious']),
      favorite_food: 'Salmon Pate',
      microchip: 'US-987654321',
      vaccinations_current: 1,
      next_vaccination: '2026-07-01'
    }
  ];
  const insertPet = db.prepare(`INSERT INTO pets
    (id,user_id,name,breed,gender,age_years,weight_kg,photo,traits,favorite_food,microchip,vaccinations_current,next_vaccination)
    VALUES (@id,@user_id,@name,@breed,@gender,@age_years,@weight_kg,@photo,@traits,@favorite_food,@microchip,@vaccinations_current,@next_vaccination)`);
  pets.forEach(p => insertPet.run(p));

  const services = [
    { id: randomUUID(), category: 'Grooming', title: 'Premium Grooming Spa', description: 'Full-service grooming including bath, haircut, nail trim, and ear cleaning', price: '$85', duration: '2 hours', distance: '2.3 mi away', rating: 4.9, review_count: 234, image: 'grooming' },
    { id: randomUUID(), category: 'Training', title: 'Obedience Training', description: 'Professional one-on-one training sessions for basic commands and behavior', price: '$120/session', duration: '1 hour', distance: '1.8 mi away', rating: 5, review_count: 189, image: 'training' },
    { id: randomUUID(), category: 'Boarding', title: 'Luxury Pet Hotel', description: 'Premium overnight boarding with private suites and 24/7 monitoring', price: '$95/night', duration: 'Per night', distance: '3.1 mi away', rating: 4.8, review_count: 456, image: 'boarding' },
    { id: randomUUID(), category: 'Veterinary', title: 'Wellness Check-Up', description: 'Comprehensive health examination with our certified veterinarians', price: '$75', duration: '45 min', distance: '1.2 mi away', rating: 4.9, review_count: 567, image: 'vet1' },
    { id: randomUUID(), category: 'Daycare', title: 'Doggy Daycare', description: 'Fun and safe daycare with supervised play and socialization', price: '$45/day', duration: 'Full day', distance: '2.7 mi away', rating: 4.7, review_count: 892, image: 'daycare' },
    { id: randomUUID(), category: 'Veterinary', title: 'Mobile Vet Service', description: 'Convenient at-home veterinary care for your pet', price: '$150', duration: '1 hour', distance: 'Comes to you', rating: 5, review_count: 123, image: 'vet2' }
  ];
  const insertService = db.prepare(`INSERT INTO services
    (id,category,title,description,price,duration,distance,rating,review_count,image)
    VALUES (@id,@category,@title,@description,@price,@duration,@distance,@rating,@review_count,@image)`);
  services.forEach(s => insertService.run(s));

  const apptId1 = randomUUID();
  const apptId2 = randomUUID();
  db.prepare(`INSERT INTO appointments (id,user_id,pet_id,service_id,title,provider,date,time,location_type,status)
    VALUES (?,?,?,?,?,?,?,?,?,?)`)
    .run(apptId1, userId, pets[0].id, services[3].id, 'Wellness Check', 'Dr. Ishika Johnson', '2026-05-28', '10:00 AM', 'In-Person', 'confirmed');
  db.prepare(`INSERT INTO appointments (id,user_id,pet_id,service_id,title,provider,date,time,location_type,status)
    VALUES (?,?,?,?,?,?,?,?,?,?)`)
    .run(apptId2, userId, pets[1].id, services[0].id, 'Grooming Session', 'Emily Chen', '2026-06-05', '2:30 PM', 'In-Person', 'pending');

  console.log('Seeded demo data for user', userId);
}

module.exports = db;
