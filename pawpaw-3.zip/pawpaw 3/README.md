# 🐾 PawPaw — Premium Pet Care Web App

A full-stack pet care platform inspired by your PetLuxe mockups — book appointments, manage pet
profiles, track health & meals, browse services, and chat with **Pawla**, your built-in AI
companion (powered by OpenAI).

This is a real, runnable project: **React (Vite) frontend + Node/Express backend + SQLite
database**. Everything works — adding pets, booking appointments, favoriting services, logging
meals, and the AI chat assistant all persist to a real local database.

---

## 1. What you need installed

- [Node.js](https://nodejs.org) v18 or newer (includes `npm`)
- VS Code (or any editor)
- An [OpenAI API key](https://platform.openai.com/api-keys) (for the AI assistant — the app still
  runs without one, the assistant just won't reply with real AI responses)

## 2. Project structure

```
pawpaw/
├── backend/          Express API + SQLite database
│   ├── server.js
│   ├── routes/        (pets, appointments, services, meals, chat, users)
│   ├── db/database.js (creates & seeds pawpaw.db automatically)
│   └── .env.example
└── frontend/          React + Vite app (the actual website)
    └── src/
        ├── pages/      Home, My Pets, Appointments, Health, Services, Activity
        ├── components/ Navbar, modals, AI Assistant widget
        └── context/    Shared app state (talks to the backend API)
```

## 3. Setup (open this folder in VS Code, then use its integrated terminal)

### Step A — Backend

```bash
cd backend
npm install
cp .env.example .env
```

Open the new `.env` file and paste in your real key:

```
OPENAI_API_KEY=sk-...your real key...
```

Then start the backend:

```bash
npm start
```

You should see: `🐾 PawPaw backend running at http://localhost:4000`
(It automatically creates `pawpaw.db` with two demo pets, sample services, and appointments the
first time it runs.)

### Step B — Frontend (open a **second** terminal, keep the backend running)

```bash
cd frontend
npm install
npm run dev
```

Vite will print a local URL — open **http://localhost:5173** in your browser. That's your live
site, talking to your real backend.

> The frontend's dev server automatically proxies any `/api/...` request to
> `http://localhost:4000`, so no extra config is needed.

## 4. What's fully working

- **My Pets** — add, edit, delete pet profiles (name, breed, age, weight, traits, favorite food);
  data is saved to SQLite and reloads on refresh.
- **Appointments** — real calendar with a live week view, available time slots that update as
  slots get booked, booking modal, cancel button.
- **Services** — category filters, favoriting (heart icon, persisted), "Book Now" opens the
  booking modal pre-filled with that service.
- **Health** — vaccination/microchip status per pet, plus a meal log you can add to and delete
  from.
- **Activity** — a live feed built from your real pets, appointments, and favorites.
- **Pawla, the AI Assistant** — a chat bubble in the bottom-right corner of every page. Ask
  pet-care questions or just vent about your day; it remembers your conversation (stored in
  SQLite) and replies using the OpenAI API on the backend, so your API key is never exposed to
  the browser.
- **Toast notifications** — every action (booking, saving, deleting, favoriting) shows a
  confirmation toast.

## 5. Customizing

- **Brand name / copy** — edit `frontend/src/pages/*.jsx` and `Navbar.jsx`.
- **Colors** — all design tokens are CSS variables at the top of `frontend/src/index.css`
  (`--orange`, `--pink`, etc.) — change them once and the whole site updates.
- **Pet photos** — currently profiles show a paw-print placeholder when no photo is set; you can
  extend `AddPetModal.jsx` to add a file upload (the backend `pets` table already has a `photo`
  column ready to store a URL or base64 string).
- **AI personality** — edit the `SYSTEM_PROMPT` constant in `backend/routes/chat.js` to change how
  Pawla talks.
- **Demo data** — edit the seed block in `backend/db/database.js`, or just delete `pawpaw.db` and
  restart the backend to reseed.

## 6. Troubleshooting

- **"Could not connect to the backend server" toast** → make sure `npm start` is running in
  `backend/` on port 4000.
- **AI assistant gives a generic fallback message** → you haven't added a real `OPENAI_API_KEY` to
  `backend/.env` yet (or it's invalid/out of quota).
- **`better-sqlite3` fails to install** → it needs to compile a small native module the first
  time. Make sure you have a working internet connection during `npm install`; on Windows you may
  need the "Desktop development with C++" workload from Visual Studio Build Tools, or just install
  recent Node.js which ships with prebuilt binaries for most platforms.
- **Port already in use** → change `PORT` in `backend/.env`, and update the proxy target in
  `frontend/vite.config.js` to match.

Enjoy building out PawPaw! 🐶🐱
