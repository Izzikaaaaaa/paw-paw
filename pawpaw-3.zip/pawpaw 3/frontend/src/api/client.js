const BASE = '/api';

async function request(path, options = {}) {
  const res = await fetch(`${BASE}${path}`, {
    headers: { 'Content-Type': 'application/json' },
    ...options
  });
  if (!res.ok) {
    let errMsg = `Request failed: ${res.status}`;
    try {
      const data = await res.json();
      errMsg = data.error || errMsg;
    } catch {}
    throw new Error(errMsg);
  }
  if (res.status === 204) return null;
  return res.json();
}

export const api = {
  // Pets
  getPets: () => request('/pets'),
  getPet: (id) => request(`/pets/${id}`),
  createPet: (data) => request('/pets', { method: 'POST', body: JSON.stringify(data) }),
  updatePet: (id, data) => request(`/pets/${id}`, { method: 'PUT', body: JSON.stringify(data) }),
  deletePet: (id) => request(`/pets/${id}`, { method: 'DELETE' }),

  // Services
  getServices: (category) => request(`/services${category && category !== 'All' ? `?category=${encodeURIComponent(category)}` : ''}`),
  toggleFavorite: (id) => request(`/services/${id}/favorite`, { method: 'POST' }),

  // Appointments
  getAppointments: () => request('/appointments'),
  getSlots: (date) => request(`/appointments/slots?date=${encodeURIComponent(date)}`),
  createAppointment: (data) => request('/appointments', { method: 'POST', body: JSON.stringify(data) }),
  updateAppointment: (id, data) => request(`/appointments/${id}`, { method: 'PUT', body: JSON.stringify(data) }),
  deleteAppointment: (id) => request(`/appointments/${id}`, { method: 'DELETE' }),

  // Meals
  getMeals: (petId) => request(`/meals/${petId}`),
  logMeal: (petId, data) => request(`/meals/${petId}`, { method: 'POST', body: JSON.stringify(data) }),
  deleteMeal: (id) => request(`/meals/entry/${id}`, { method: 'DELETE' }),

  // Chat
  getChatHistory: () => request('/chat/history'),
  sendChatMessage: (message) => request('/chat/message', { method: 'POST', body: JSON.stringify({ message }) }),
  clearChatHistory: () => request('/chat/history', { method: 'DELETE' }),

  // User
  getMe: () => request('/users/me'),
  updateMe: (data) => request('/users/me', { method: 'PUT', body: JSON.stringify(data) })
};
