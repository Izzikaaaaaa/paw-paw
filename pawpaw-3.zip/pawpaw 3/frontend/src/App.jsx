import React from 'react';
import { Routes, Route } from 'react-router-dom';
import { ToastProvider } from './context/ToastContext';
import { AppDataProvider, useAppData } from './context/AppDataContext';
import Navbar from './components/Navbar';
import AIAssistant from './components/AIAssistant';
import Home from './pages/Home';
import MyPets from './pages/MyPets';
import Appointments from './pages/Appointments';
import Health from './pages/Health';
import Services from './pages/Services';
import ActivityPage from './pages/ActivityPage';

function Shell() {
  const { loading } = useAppData();

  return (
    <div className="app-shell">
      <Navbar />
      <main>
        {loading ? (
          <div className="page-loading">
            <div className="spinner" />
            <p>Fetching your pets' world…</p>
          </div>
        ) : (
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/pets" element={<MyPets />} />
            <Route path="/appointments" element={<Appointments />} />
            <Route path="/health" element={<Health />} />
            <Route path="/services" element={<Services />} />
            <Route path="/activity" element={<ActivityPage />} />
          </Routes>
        )}
      </main>
      <AIAssistant />
    </div>
  );
}

export default function App() {
  return (
    <ToastProvider>
      <AppDataProvider>
        <Shell />
      </AppDataProvider>
    </ToastProvider>
  );
}
