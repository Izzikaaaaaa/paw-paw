import React, { useEffect, useRef, useState, useCallback } from 'react';
import { MessageCircle, X, Send, Sparkles, Trash2 } from 'lucide-react';
import { api } from '../api/client';
import { useToast } from '../context/ToastContext';

const STARTER_PROMPTS = [
  "My dog has been scratching a lot lately 🐾",
  "I'm feeling overwhelmed with pet care",
  "What human foods are toxic to dogs?",
  "Just want to chat about my day"
];

let msgId = 0;
function localId() { return `local-${++msgId}`; }

export default function AIAssistant() {
  const { showToast } = useToast();
  const [open, setOpen] = useState(false);
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState('');
  const [sending, setSending] = useState(false);
  const historyLoadedRef = useRef(false);
  const scrollRef = useRef(null);
  const inputRef = useRef(null);

  // Load chat history once when panel first opens
  useEffect(() => {
    if (!open || historyLoadedRef.current) return;
    api.getChatHistory()
      .then((history) => {
        setMessages(history.map(m => ({ ...m, _key: localId() })));
        historyLoadedRef.current = true;
      })
      .catch(() => { historyLoadedRef.current = true; });
  }, [open]);

  // Scroll to bottom whenever messages change or panel opens
  useEffect(() => {
    if (!scrollRef.current) return;
    requestAnimationFrame(() => {
      if (scrollRef.current) {
        scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
      }
    });
  }, [messages, sending, open]);

  // Focus input when panel opens
  useEffect(() => {
    if (open && inputRef.current) {
      setTimeout(() => inputRef.current?.focus(), 120);
    }
  }, [open]);

  const sendMessage = useCallback(async (text) => {
    const content = (text ?? input).trim();
    if (!content || sending) return;

    setInput('');
    setSending(true);

    // Optimistically add the user message to UI
    const userKey = localId();
    setMessages(prev => [...prev, {
      _key: userKey,
      role: 'user',
      content,
      created_at: new Date().toISOString()
    }]);

    try {
      const reply = await api.sendChatMessage(content);
      setMessages(prev => [...prev, { ...reply, _key: localId() }]);
    } catch (err) {
      // Remove the optimistic user message on failure
      setMessages(prev => prev.filter(m => m._key !== userKey));
      showToast(
        err.message?.includes('API key') || err.message?.includes('401')
          ? 'Add your OpenAI key to backend/.env to enable Pawla'
          : (err.message || 'Pawla is having trouble right now — try again'),
        'error'
      );
    } finally {
      setSending(false);
    }
  }, [input, sending, showToast]);

  async function handleClear() {
    try {
      await api.clearChatHistory();
      setMessages([]);
      historyLoadedRef.current = true; // already blank, no need to re-fetch
      showToast('Chat cleared', 'info');
    } catch (err) {
      showToast(err.message || 'Could not clear chat', 'error');
    }
  }

  function handleKeyDown(e) {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  }

  return (
    <>
      <button
        className={`ai-fab${open ? ' ai-fab-open' : ''}`}
        onClick={() => setOpen(o => !o)}
        aria-label={open ? 'Close AI assistant' : 'Open AI assistant (Pawla)'}
      >
        {open ? <X size={22} /> : <Sparkles size={22} />}
      </button>

      {open && (
        <div className="ai-panel" role="dialog" aria-label="Pawla — AI assistant">
          <div className="ai-panel-header">
            <div className="ai-panel-title">
              <div className="ai-avatar-circle">
                <Sparkles size={14} />
              </div>
              <div>
                <strong>Pawla</strong>
                <small>Your caring AI companion 🐾</small>
              </div>
            </div>
            <div className="ai-panel-actions">
              <button className="icon-btn ai-icon-btn" onClick={handleClear} aria-label="Clear chat history" title="Clear chat">
                <Trash2 size={15} />
              </button>
              <button className="icon-btn ai-icon-btn" onClick={() => setOpen(false)} aria-label="Close">
                <X size={17} />
              </button>
            </div>
          </div>

          <div className="ai-panel-body" ref={scrollRef}>
            {messages.length === 0 && (
              <div className="ai-empty">
                <p>Hi! I'm here for pet-care questions, tips, or just to talk. What's on your mind?</p>
                <div className="ai-starters">
                  {STARTER_PROMPTS.map(p => (
                    <button
                      key={p}
                      className="ai-starter-btn"
                      onClick={() => sendMessage(p)}
                      disabled={sending}
                    >
                      {p}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {messages.map(m => (
              <div key={m._key || m.id} className={`ai-msg ai-msg-${m.role}`}>
                {m.role === 'assistant' && (
                  <span className="ai-msg-avatar"><Sparkles size={11} /></span>
                )}
                <div className="ai-bubble">{m.content}</div>
              </div>
            ))}

            {sending && (
              <div className="ai-msg ai-msg-assistant">
                <span className="ai-msg-avatar"><Sparkles size={11} /></span>
                <div className="ai-bubble ai-typing">
                  <span /><span /><span />
                </div>
              </div>
            )}
          </div>

          <form
            className="ai-panel-input"
            onSubmit={e => { e.preventDefault(); sendMessage(); }}
          >
            <input
              ref={inputRef}
              value={input}
              onChange={e => setInput(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="Ask Pawla anything…"
              disabled={sending}
              aria-label="Message Pawla"
            />
            <button
              type="submit"
              className="ai-send-btn"
              disabled={sending || !input.trim()}
              aria-label="Send message"
            >
              <Send size={16} />
            </button>
          </form>
        </div>
      )}
    </>
  );
}
