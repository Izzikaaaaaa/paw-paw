import React from 'react';
import { NavLink } from 'react-router-dom';
import { Heart, User, Calendar, Activity, Sparkles, ShoppingBag, PawPrint } from 'lucide-react';
import { useAppData } from '../context/AppDataContext';

const NAV_ITEMS = [
  { to: '/', label: 'Home', icon: Heart, end: true },
  { to: '/pets', label: 'My Pets', icon: User },
  { to: '/appointments', label: 'Appointments', icon: Calendar },
  { to: '/health', label: 'Health', icon: Activity },
  { to: '/services', label: 'Services', icon: ShoppingBag },
  { to: '/activity', label: 'Activity', icon: Sparkles }
];

export default function Navbar() {
  const { user } = useAppData();
  const initials = user?.name ? user.name.split(' ').map((p) => p[0]).join('').slice(0, 2) : 'S';

  return (
    <header className="navbar">
      <div className="navbar-inner">
        <NavLink to="/" className="brand">
          <span className="brand-icon"><PawPrint size={22} strokeWidth={2.5} /></span>
          <span className="brand-text">
            <span className="brand-name">PawPaw</span>
            <span className="brand-sub">Premium Pet Care</span>
          </span>
        </NavLink>

        <nav className="nav-links">
          {NAV_ITEMS.map(({ to, label, icon: Icon, end }) => (
            <NavLink
              key={to}
              to={to}
              end={end}
              className={({ isActive }) => `nav-link${isActive ? ' nav-link-active' : ''}`}
            >
              <Icon size={16} />
              <span>{label}</span>
            </NavLink>
          ))}
        </nav>

        <div className="navbar-user">
          <div className="avatar-pill">
            <span className="avatar-circle">{initials}</span>
            <span className="avatar-name">{user?.name || 'Guest'}</span>
          </div>
        </div>
      </div>
    </header>
  );
}
