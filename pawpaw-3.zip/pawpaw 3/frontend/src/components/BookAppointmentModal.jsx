import React, { useEffect, useState } from 'react';
import Modal from './Modal';
import { useAppData } from '../context/AppDataContext';
import { useToast } from '../context/ToastContext';
import { api } from '../api/client';

function todayISO() {
  return new Date().toISOString().slice(0, 10);
}

export default function BookAppointmentModal({ open, onClose, presetService }) {
  const { pets, bookAppointment } = useAppData();
  const { showToast } = useToast();
  const [petId, setPetId] = useState('');
  const [title, setTitle] = useState('');
  const [date, setDate] = useState(todayISO());
  const [slots, setSlots] = useState([]);
  const [selectedSlot, setSelectedSlot] = useState(null);
  const [notes, setNotes] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [loadingSlots, setLoadingSlots] = useState(false);

  useEffect(() => {
    if (open) {
      setPetId(pets[0]?.id || '');
      setTitle(presetService?.title || '');
      setDate(todayISO());
      setNotes('');
      setSelectedSlot(null);
    }
  }, [open, pets, presetService]);

  useEffect(() => {
    if (!open || !date) return;
    setLoadingSlots(true);
    api.getSlots(date)
      .then(setSlots)
      .catch(() => setSlots([]))
      .finally(() => setLoadingSlots(false));
  }, [date, open]);

  async function handleSubmit(e) {
    e.preventDefault();
    if (!title.trim()) return showToast('Please enter an appointment title', 'error');
    if (!selectedSlot) return showToast('Please select a time slot', 'error');

    setSubmitting(true);
    try {
      await bookAppointment({
        pet_id: petId || null,
        service_id: presetService?.id || null,
        title: title.trim(),
        provider: selectedSlot.provider,
        date,
        time: selectedSlot.time,
        location_type: 'In-Person',
        notes
      });
      onClose();
    } catch (err) {
      showToast(err.message || 'Could not book appointment', 'error');
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <Modal open={open} onClose={onClose} title="Book Appointment" width="560px">
      <form className="form-grid" onSubmit={handleSubmit}>
        <label className="field">
          <span>Appointment Title *</span>
          <input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="e.g. Wellness Check" required />
        </label>

        <label className="field">
          <span>Pet</span>
          <select value={petId} onChange={(e) => setPetId(e.target.value)}>
            <option value="">No specific pet</option>
            {pets.map((p) => (
              <option key={p.id} value={p.id}>{p.name}</option>
            ))}
          </select>
        </label>

        <label className="field">
          <span>Date</span>
          <input type="date" value={date} min={todayISO()} onChange={(e) => setDate(e.target.value)} />
        </label>

        <div className="field">
          <span>Available Time Slots</span>
          {loadingSlots ? (
            <p className="muted">Loading slots…</p>
          ) : (
            <div className="slot-grid">
              {slots.map((slot) => (
                <button
                  type="button"
                  key={slot.time}
                  disabled={!slot.available}
                  className={`slot-btn${selectedSlot?.time === slot.time ? ' slot-btn-selected' : ''}`}
                  onClick={() => setSelectedSlot(slot)}
                >
                  <strong>{slot.time}</strong>
                  <small>{slot.available ? slot.provider : 'Booked'}</small>
                </button>
              ))}
            </div>
          )}
        </div>

        <label className="field">
          <span>Notes (optional)</span>
          <textarea rows={2} value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="Anything the provider should know?" />
        </label>

        <div className="modal-actions">
          <button type="button" className="btn btn-ghost" onClick={onClose}>Cancel</button>
          <button type="submit" className="btn btn-gradient" disabled={submitting}>
            {submitting ? 'Booking…' : 'Confirm Booking'}
          </button>
        </div>
      </form>
    </Modal>
  );
}
