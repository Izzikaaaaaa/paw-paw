import React, { useEffect, useState } from 'react';
import Modal from './Modal';
import { useAppData } from '../context/AppDataContext';
import { useToast } from '../context/ToastContext';

const EMPTY = { name: '', breed: '', gender: 'Male', age_years: '', weight_kg: '', favorite_food: '', traits: '' };

export default function AddPetModal({ open, onClose, editingPet }) {
  const { addPet, updatePet } = useAppData();
  const { showToast } = useToast();
  const [form, setForm] = useState(EMPTY);
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    if (editingPet) {
      setForm({
        name: editingPet.name || '',
        breed: editingPet.breed || '',
        gender: editingPet.gender || 'Male',
        age_years: editingPet.age_years ?? '',
        weight_kg: editingPet.weight_kg ?? '',
        favorite_food: editingPet.favorite_food || '',
        traits: (editingPet.traits || []).join(', ')
      });
    } else {
      setForm(EMPTY);
    }
  }, [editingPet, open]);

  function update(field, value) {
    setForm((f) => ({ ...f, [field]: value }));
  }

  async function handleSubmit(e) {
    e.preventDefault();
    if (!form.name.trim()) {
      showToast('Please give your pet a name', 'error');
      return;
    }
    setSubmitting(true);
    try {
      const payload = {
        name: form.name.trim(),
        breed: form.breed.trim(),
        gender: form.gender,
        age_years: form.age_years ? parseFloat(form.age_years) : 0,
        weight_kg: form.weight_kg ? parseFloat(form.weight_kg) : 0,
        favorite_food: form.favorite_food.trim(),
        traits: form.traits.split(',').map((t) => t.trim()).filter(Boolean)
      };
      if (editingPet) {
        await updatePet(editingPet.id, payload);
      } else {
        await addPet(payload);
      }
      onClose();
    } catch (err) {
      showToast(err.message || 'Something went wrong', 'error');
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <Modal open={open} onClose={onClose} title={editingPet ? 'Edit Pet Profile' : 'Add New Pet'}>
      <form className="form-grid" onSubmit={handleSubmit}>
        <label className="field">
          <span>Pet Name *</span>
          <input value={form.name} onChange={(e) => update('name', e.target.value)} placeholder="e.g. Max" required />
        </label>
        <label className="field">
          <span>Breed</span>
          <input value={form.breed} onChange={(e) => update('breed', e.target.value)} placeholder="e.g. Golden Retriever" />
        </label>
        <div className="field-row">
          <label className="field">
            <span>Gender</span>
            <select value={form.gender} onChange={(e) => update('gender', e.target.value)}>
              <option>Male</option>
              <option>Female</option>
            </select>
          </label>
          <label className="field">
            <span>Age (years)</span>
            <input type="number" min="0" step="0.5" value={form.age_years} onChange={(e) => update('age_years', e.target.value)} placeholder="3" />
          </label>
        </div>
        <div className="field-row">
          <label className="field">
            <span>Weight (kg)</span>
            <input type="number" min="0" step="0.1" value={form.weight_kg} onChange={(e) => update('weight_kg', e.target.value)} placeholder="32" />
          </label>
          <label className="field">
            <span>Favorite Food</span>
            <input value={form.favorite_food} onChange={(e) => update('favorite_food', e.target.value)} placeholder="Chicken & Rice" />
          </label>
        </div>
        <label className="field">
          <span>Traits (comma-separated)</span>
          <input value={form.traits} onChange={(e) => update('traits', e.target.value)} placeholder="Playful, Friendly, Energetic" />
        </label>

        <div className="modal-actions">
          <button type="button" className="btn btn-ghost" onClick={onClose}>Cancel</button>
          <button type="submit" className="btn btn-gradient" disabled={submitting}>
            {submitting ? 'Saving…' : editingPet ? 'Save Changes' : 'Add Pet'}
          </button>
        </div>
      </form>
    </Modal>
  );
}
