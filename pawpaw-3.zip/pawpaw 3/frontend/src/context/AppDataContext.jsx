import React, { createContext, useCallback, useContext, useEffect, useState } from 'react';
import { api } from '../api/client';
import { useToast } from './ToastContext';

const AppDataContext = createContext(null);

export function AppDataProvider({ children }) {
  const { showToast } = useToast();
  const [user, setUser] = useState(null);
  const [pets, setPets] = useState([]);
  const [appointments, setAppointments] = useState([]);
  const [services, setServices] = useState([]);
  const [loading, setLoading] = useState(true);

  const refreshPets = useCallback(async () => {
    const data = await api.getPets();
    setPets(data);
    return data;
  }, []);

  const refreshAppointments = useCallback(async () => {
    const data = await api.getAppointments();
    setAppointments(data);
    return data;
  }, []);

  const refreshServices = useCallback(async (category) => {
    const data = await api.getServices(category);
    setServices(data);
    return data;
  }, []);

  useEffect(() => {
    (async () => {
      try {
        const [u, p, a, s] = await Promise.all([
          api.getMe(),
          api.getPets(),
          api.getAppointments(),
          api.getServices()
        ]);
        setUser(u);
        setPets(p);
        setAppointments(a);
        setServices(s);
      } catch (err) {
        showToast(err.message || 'Could not connect to the backend server', 'error');
      } finally {
        setLoading(false);
      }
    })();
  }, [showToast]);

  const addPet = useCallback(async (petData) => {
    const pet = await api.createPet(petData);
    setPets((prev) => [...prev, pet]);
    showToast(`${pet.name}'s profile has been added!`, 'success');
    return pet;
  }, [showToast]);

  const updatePet = useCallback(async (id, petData) => {
    const pet = await api.updatePet(id, petData);
    setPets((prev) => prev.map((p) => (p.id === id ? pet : p)));
    showToast(`${pet.name}'s profile was updated`, 'success');
    return pet;
  }, [showToast]);

  const removePet = useCallback(async (id, name) => {
    await api.deletePet(id);
    setPets((prev) => prev.filter((p) => p.id !== id));
    showToast(`${name || 'Pet'} was removed`, 'info');
  }, [showToast]);

  const bookAppointment = useCallback(async (data) => {
    const appt = await api.createAppointment(data);
    setAppointments((prev) => [...prev, appt].sort((a, b) => (a.date + a.time).localeCompare(b.date + b.time)));
    showToast('Appointment booked successfully!', 'success');
    return appt;
  }, [showToast]);

  const cancelAppointment = useCallback(async (id) => {
    await api.deleteAppointment(id);
    setAppointments((prev) => prev.filter((a) => a.id !== id));
    showToast('Appointment cancelled', 'info');
  }, [showToast]);

  const updateAppointmentStatus = useCallback(async (id, status) => {
    const appt = await api.updateAppointment(id, { status });
    setAppointments((prev) => prev.map((a) => (a.id === id ? appt : a)));
    showToast(`Appointment marked as ${status}`, 'success');
    return appt;
  }, [showToast]);

  const toggleFavorite = useCallback(async (id) => {
    const { favorited } = await api.toggleFavorite(id);
    setServices((prev) => prev.map((s) => (s.id === id ? { ...s, favorited } : s)));
    showToast(favorited ? 'Added to favorites' : 'Removed from favorites', favorited ? 'success' : 'info');
  }, [showToast]);

  const value = {
    user, setUser,
    pets, setPets, refreshPets, addPet, updatePet, removePet,
    appointments, setAppointments, refreshAppointments, bookAppointment, cancelAppointment, updateAppointmentStatus,
    services, setServices, refreshServices, toggleFavorite,
    loading
  };

  return <AppDataContext.Provider value={value}>{children}</AppDataContext.Provider>;
}

export function useAppData() {
  const ctx = useContext(AppDataContext);
  if (!ctx) throw new Error('useAppData must be used within AppDataProvider');
  return ctx;
}
