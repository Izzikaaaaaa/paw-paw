import React, { useState } from 'react';
import { Plus, Calendar, Edit3, Trash2, PawPrint, MapPin, Ruler, Weight, Drumstick, BadgeCheck, Syringe } from 'lucide-react';
import { useAppData } from '../context/AppDataContext';
import { useToast } from '../context/ToastContext';
import AddPetModal from '../components/AddPetModal';
import BookAppointmentModal from '../components/BookAppointmentModal';

export default function MyPets() {
  const { pets, removePet } = useAppData();
  const { showToast } = useToast();
  const [selectedId, setSelectedId] = useState(null);
  const [addOpen, setAddOpen] = useState(false);
  const [editingPet, setEditingPet] = useState(null);
  const [bookOpen, setBookOpen] = useState(false);

  const selected = pets.find((p) => p.id === selectedId) || pets[0];

  async function handleRemove(pet) {
    if (!window.confirm(`Remove ${pet.name} from your profile? This can't be undone.`)) return;
    try {
      await removePet(pet.id, pet.name);
      if (selectedId === pet.id) setSelectedId(null);
    } catch (err) {
      showToast(err.message || 'Could not remove pet', 'error');
    }
  }

  return (
    <div className="page">
      <div className="page-header">
        <div>
          <h1>My Pets</h1>
          <p>Manage your pets' profiles and information</p>
        </div>
        <button className="btn btn-gradient" onClick={() => { setEditingPet(null); setAddOpen(true); }}>
          <Plus size={18} /> Add New Pet
        </button>
      </div>

      {pets.length === 0 ? (
        <div className="empty-state">
          <PawPrint size={40} />
          <h3>No pets yet</h3>
          <p>Add your first pet to start tracking their health and booking services.</p>
          <button className="btn btn-gradient" onClick={() => setAddOpen(true)}><Plus size={16} /> Add New Pet</button>
        </div>
      ) : (
        <>
          <div className="pet-card-row">
            {pets.map((pet) => (
              <button
                key={pet.id}
                className={`pet-chip${selected?.id === pet.id ? ' pet-chip-active' : ''}`}
                onClick={() => setSelectedId(pet.id)}
              >
                <span className="pet-chip-avatar">
                  {pet.photo ? <img src={pet.photo} alt={pet.name} /> : <PawPrint size={20} />}
                </span>
                <span className="pet-chip-info">
                  <strong>{pet.name}</strong>
                  <small>{pet.breed || 'Unknown breed'}</small>
                </span>
                <span className="pet-chip-tags">
                  {pet.age_years ? <span className="tag tag-yellow">{pet.age_years} years</span> : null}
                  {pet.weight_kg ? <span className="tag tag-purple">{pet.weight_kg} kg</span> : null}
                </span>
              </button>
            ))}
          </div>

          {selected && (
            <div className="pet-detail-grid">
              <div className="pet-photo-card">
                <div className="pet-photo">
                  <img
                    src={selected.photo || 'https://images.unsplash.com/photo-1529429617124-95b109e86bb8?w=400&q=80'}
                    alt={selected.name}
                    onError={e => { e.target.style.display='none'; e.target.parentNode.dataset.noimg='1'; }}
                  />
                </div>
                <h2>{selected.name}</h2>
                <p className="muted">{selected.breed || 'Unknown breed'}</p>
                <div className="trait-row">
                  {(selected.traits || []).map((t) => (
                    <span className="tag tag-soft" key={t}>{t}</span>
                  ))}
                </div>
              </div>

              <div className="detail-card">
                <h3>Profile Details</h3>
                <ul className="detail-list">
                  <li><span className="detail-icon detail-icon-yellow"><Calendar size={16} /></span><div><small>Age</small><strong>{selected.age_years || 0} years</strong></div></li>
                  <li><span className="detail-icon detail-icon-yellow"><BadgeCheck size={16} /></span><div><small>Breed</small><strong>{selected.breed || 'Unknown'}</strong></div></li>
                  <li><span className="detail-icon detail-icon-yellow"><MapPin size={16} /></span><div><small>Gender</small><strong>{selected.gender || 'Unknown'}</strong></div></li>
                  <li><span className="detail-icon detail-icon-yellow"><Weight size={16} /></span><div><small>Current Weight</small><strong>{selected.weight_kg || 0} kg</strong></div></li>
                  <li><span className="detail-icon detail-icon-yellow"><Drumstick size={16} /></span><div><small>Favorite Food</small><strong>{selected.favorite_food || 'Not set'}</strong></div></li>
                </ul>
              </div>

              <div className="detail-card">
                <h3>Health Information</h3>
                <div className={`health-banner ${selected.vaccinations_current ? 'health-good' : 'health-warn'}`}>
                  <BadgeCheck size={18} />
                  <div>
                    <strong>{selected.vaccinations_current ? 'Up to Date' : 'Needs Attention'}</strong>
                    <small>{selected.vaccinations_current ? 'All vaccinations current' : 'Vaccinations overdue'}</small>
                    {selected.next_vaccination && <small>Next: {selected.next_vaccination}</small>}
                  </div>
                </div>
                <div className="microchip-banner">
                  <Syringe size={18} />
                  <div>
                    <strong>Microchip</strong>
                    <small>{selected.microchip || 'Not registered'}</small>
                  </div>
                </div>

                <div className="detail-actions">
                  <button className="btn btn-gradient btn-block" onClick={() => { setEditingPet(selected); setAddOpen(true); }}>
                    <Edit3 size={16} /> Edit Profile
                  </button>
                  <button className="btn btn-outline btn-block" onClick={() => setBookOpen(true)}>
                    <Calendar size={16} /> Book Appointment
                  </button>
                  <button className="btn btn-danger btn-block" onClick={() => handleRemove(selected)}>
                    <Trash2 size={16} /> Remove Pet
                  </button>
                </div>
              </div>
            </div>
          )}
        </>
      )}

      <AddPetModal open={addOpen} onClose={() => setAddOpen(false)} editingPet={editingPet} />
      <BookAppointmentModal
        open={bookOpen}
        onClose={() => setBookOpen(false)}
        presetService={selected ? { title: `${selected.name}'s Appointment` } : null}
      />
    </div>
  );
}
