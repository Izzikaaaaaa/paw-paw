import React, { useEffect, useState } from 'react';
import { Star, MapPin, Clock, Heart, Scissors, GraduationCap, Building2, Stethoscope, Sun, HeartHandshake } from 'lucide-react';
import { useAppData } from '../context/AppDataContext';
import BookAppointmentModal from '../components/BookAppointmentModal';

const CATEGORIES = ['All', 'Grooming', 'Training', 'Boarding', 'Veterinary', 'Daycare'];

const CATEGORY_ICON = {
  Grooming: Scissors,
  Training: GraduationCap,
  Boarding: Building2,
  Veterinary: Stethoscope,
  Daycare: Sun,
  Wellness: HeartHandshake
};

export default function Services() {
  const { services, refreshServices, toggleFavorite } = useAppData();
  const [category, setCategory] = useState('All');
  const [bookOpen, setBookOpen] = useState(false);
  const [chosenService, setChosenService] = useState(null);

  useEffect(() => {
    refreshServices(category);
  }, [category, refreshServices]);

  function openBooking(service) {
    setChosenService(service);
    setBookOpen(true);
  }

  return (
    <div className="page">
      <div className="page-header">
        <div>
          <h1>Premium Services</h1>
          <p>Discover top-rated pet care services near you</p>
        </div>
      </div>

      <div className="category-row">
        {CATEGORIES.map((c) => (
          <button
            key={c}
            className={`category-pill${category === c ? ' category-pill-active' : ''}`}
            onClick={() => setCategory(c)}
          >
            {c}
          </button>
        ))}
      </div>

      <div className="service-grid">
        {services.map((s) => (
          <div className="service-card" key={s.id}>
            <div className={`service-image service-image-${s.image}`}>
              <span className="service-badge">{s.category}</span>
              <button
                className={`fav-btn${s.favorited ? ' fav-btn-active' : ''}`}
                onClick={() => toggleFavorite(s.id)}
                aria-label="Toggle favorite"
              >
                <Heart size={16} fill={s.favorited ? 'currentColor' : 'none'} />
              </button>
              <span className="service-rating"><Star size={13} fill="currentColor" /> {s.rating} ({s.review_count})</span>
            </div>
            <div className="service-body">
              <h3>{s.title}</h3>
              <p>{s.description}</p>
              <div className="service-meta">
                <span>💲 {s.price}</span>
                <span><Clock size={13} /> {s.duration}</span>
                <span><MapPin size={13} /> {s.distance}</span>
              </div>
              <button className="btn btn-gradient btn-block" onClick={() => openBooking(s)}>Book Now</button>
            </div>
          </div>
        ))}
      </div>

      <section className="popular-categories">
        <h2>Popular Categories</h2>
        <div className="popular-grid">
          {Object.entries(CATEGORY_ICON).map(([name, Icon]) => (
            <button key={name} className="popular-chip" onClick={() => setCategory(name === 'Wellness' ? 'All' : name)}>
              <span className="popular-chip-icon"><Icon size={20} /></span>
              <small>{name}</small>
            </button>
          ))}
        </div>
      </section>

      <BookAppointmentModal open={bookOpen} onClose={() => setBookOpen(false)} presetService={chosenService} />
    </div>
  );
}
