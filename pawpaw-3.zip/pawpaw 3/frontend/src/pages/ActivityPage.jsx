import React from 'react';
import { Calendar, Utensils, PawPrint, Heart, ShoppingBag } from 'lucide-react';
import { useAppData } from '../context/AppDataContext';

export default function ActivityPage() {
  const { appointments, pets, services } = useAppData();

  const favoriteServices = services.filter((s) => s.favorited);

  const events = [
    ...appointments.map((a) => ({
      type: 'appointment',
      icon: Calendar,
      title: `${a.title} booked`,
      detail: `${a.pet_name ? a.pet_name + ' • ' : ''}${a.date} at ${a.time}`,
      color: 'orange'
    })),
    ...pets.map((p) => ({
      type: 'pet',
      icon: PawPrint,
      title: `${p.name}'s profile`,
      detail: `${p.breed || 'Pet'} • ${p.age_years || 0} years old`,
      color: 'pink'
    })),
    ...favoriteServices.map((s) => ({
      type: 'favorite',
      icon: Heart,
      title: `Favorited ${s.title}`,
      detail: s.category,
      color: 'magenta'
    }))
  ];

  return (
    <div className="page">
      <div className="page-header">
        <div>
          <h1>Activity</h1>
          <p>A snapshot of everything happening with your pets</p>
        </div>
      </div>

      {events.length === 0 ? (
        <div className="empty-state">
          <ShoppingBag size={40} />
          <h3>No activity yet</h3>
          <p>Add a pet, book an appointment, or favorite a service to see it here.</p>
        </div>
      ) : (
        <div className="timeline">
          {events.map((e, i) => (
            <div className="timeline-item" key={i}>
              <span className={`timeline-icon timeline-icon-${e.color}`}><e.icon size={16} /></span>
              <div>
                <strong>{e.title}</strong>
                <p className="muted">{e.detail}</p>
              </div>
            </div>
          ))}
        </div>
      )}

      <section className="stats-row">
        <div className="stat-box">
          <strong>{pets.length}</strong>
          <span>Pets</span>
        </div>
        <div className="stat-box">
          <strong>{appointments.length}</strong>
          <span>Appointments</span>
        </div>
        <div className="stat-box">
          <strong>{favoriteServices.length}</strong>
          <span>Favorited Services</span>
        </div>
      </section>
    </div>
  );
}
