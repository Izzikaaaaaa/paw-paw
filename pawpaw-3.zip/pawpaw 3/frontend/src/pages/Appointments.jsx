import React, { useEffect, useMemo, useState } from 'react';
import { Calendar, Clock, User, MapPin, ChevronLeft, ChevronRight, X } from 'lucide-react';
import { useAppData } from '../context/AppDataContext';
import { useToast } from '../context/ToastContext';
import { api } from '../api/client';
import BookAppointmentModal from '../components/BookAppointmentModal';

function startOfWeek(date) {
  const d = new Date(date);
  const day = d.getDay();
  const diff = day === 0 ? -6 : 1 - day; // Monday as first day
  d.setDate(d.getDate() + diff);
  return d;
}

function fmtISO(date) {
  return date.toISOString().slice(0, 10);
}

const DAY_LABELS = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
const MONTH_NAMES = ['January','February','March','April','May','June','July','August','September','October','November','December'];

export default function Appointments() {
  const { pets, appointments, bookAppointment, cancelAppointment } = useAppData();
  const { showToast } = useToast();
  const [weekStart, setWeekStart] = useState(startOfWeek(new Date()));
  const [selectedDate, setSelectedDate] = useState(fmtISO(new Date()));
  const [slots, setSlots] = useState([]);
  const [loadingSlots, setLoadingSlots] = useState(false);
  const [bookOpen, setBookOpen] = useState(false);
  const [quickTitle, setQuickTitle] = useState('');
  const [quickPet, setQuickPet] = useState('');

  const weekDays = useMemo(() => {
    return Array.from({ length: 7 }, (_, i) => {
      const d = new Date(weekStart);
      d.setDate(weekStart.getDate() + i);
      return d;
    });
  }, [weekStart]);

  useEffect(() => {
    setLoadingSlots(true);
    api.getSlots(selectedDate)
      .then(setSlots)
      .catch(() => setSlots([]))
      .finally(() => setLoadingSlots(false));
  }, [selectedDate]);

  function shiftWeek(delta) {
    const d = new Date(weekStart);
    d.setDate(d.getDate() + delta * 7);
    setWeekStart(d);
  }

  async function handleSlotBook(slot) {
    if (!quickTitle.trim()) {
      showToast('Add a quick title for your appointment first (e.g. "Wellness Check")', 'info');
      return;
    }
    try {
      await bookAppointment({
        pet_id: quickPet || null,
        title: quickTitle.trim(),
        provider: slot.provider,
        date: selectedDate,
        time: slot.time,
        location_type: 'In-Person'
      });
      setSlots((prev) => prev.map((s) => (s.time === slot.time ? { ...s, available: false } : s)));
      setQuickTitle('');
    } catch (err) {
      showToast(err.message || 'Could not book that slot', 'error');
    }
  }

  const upcoming = appointments.filter((a) => a.status !== 'cancelled');
  const selectedDateObj = new Date(selectedDate + 'T00:00:00');

  return (
    <div className="page">
      <div className="page-header">
        <div>
          <h1>Appointments</h1>
          <p>Book and manage your pet care appointments</p>
        </div>
        <button className="btn btn-gradient" onClick={() => setBookOpen(true)}>
          <Calendar size={18} /> New Appointment
        </button>
      </div>

      <div className="appointments-grid">
        <div className="card">
          <div className="card-header-row">
            <h3>Select Date</h3>
            <div className="month-nav">
              <span>{MONTH_NAMES[weekStart.getMonth()]} {weekStart.getFullYear()}</span>
              <button className="icon-btn" onClick={() => shiftWeek(-1)}><ChevronLeft size={16} /></button>
              <button className="icon-btn" onClick={() => shiftWeek(1)}><ChevronRight size={16} /></button>
            </div>
          </div>
          <div className="week-grid">
            {weekDays.map((d, i) => {
              const iso = fmtISO(d);
              const isSelected = iso === selectedDate;
              return (
                <button
                  key={iso}
                  className={`day-cell${isSelected ? ' day-cell-active' : ''}`}
                  onClick={() => setSelectedDate(iso)}
                >
                  <small>{DAY_LABELS[i]}</small>
                  <strong>{d.getDate()}</strong>
                </button>
              );
            })}
          </div>

          <h3 className="mt-lg">Available Time Slots — {MONTH_NAMES[selectedDateObj.getMonth()]} {selectedDateObj.getDate()}</h3>
          <div className="quick-book-row">
            <input
              placeholder="Appointment title (e.g. Wellness Check)"
              value={quickTitle}
              onChange={(e) => setQuickTitle(e.target.value)}
            />
            <select value={quickPet} onChange={(e) => setQuickPet(e.target.value)}>
              <option value="">No specific pet</option>
              {pets.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}
            </select>
          </div>
          {loadingSlots ? (
            <p className="muted">Loading slots…</p>
          ) : (
            <div className="slot-grid">
              {slots.map((slot) => (
                <button
                  key={slot.time}
                  disabled={!slot.available}
                  className={`slot-btn${slot.available ? '' : ' slot-btn-disabled'}`}
                  onClick={() => handleSlotBook(slot)}
                >
                  <strong>{slot.time}</strong>
                  <small>{slot.available ? slot.provider : 'Booked'}</small>
                </button>
              ))}
            </div>
          )}
        </div>

        <div className="card">
          <h3>Upcoming</h3>
          {upcoming.length === 0 ? (
            <p className="muted">No appointments yet — book one to get started!</p>
          ) : (
            <div className="appt-list">
              {upcoming.map((a) => (
                <div className="appt-card" key={a.id}>
                  <div className="appt-card-top">
                    <strong>{a.title}</strong>
                    <span className={`status-badge status-${a.status}`}>{a.status}</span>
                  </div>
                  {a.pet_name && <small className="muted">{a.pet_name}</small>}
                  <div className="appt-meta">
                    <span><Calendar size={13} /> {a.date}</span>
                    <span><Clock size={13} /> {a.time}</span>
                    <span><User size={13} /> {a.provider}</span>
                    <span><MapPin size={13} /> {a.location_type}</span>
                  </div>
                  <button className="appt-cancel" onClick={() => cancelAppointment(a.id)}>
                    <X size={13} /> Cancel
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      <BookAppointmentModal open={bookOpen} onClose={() => setBookOpen(false)} />
    </div>
  );
}
