import React, { useEffect, useState } from 'react';
import { Activity, BadgeCheck, Syringe, Plus, Trash2, Utensils } from 'lucide-react';
import { useAppData } from '../context/AppDataContext';
import { useToast } from '../context/ToastContext';
import { api } from '../api/client';

export default function Health() {
  const { pets } = useAppData();
  const { showToast } = useToast();
  const [selectedId, setSelectedId] = useState(null);
  const [meals, setMeals] = useState([]);
  const [food, setFood] = useState('');
  const [amount, setAmount] = useState('');
  const [loadingMeals, setLoadingMeals] = useState(false);

  const selected = pets.find((p) => p.id === selectedId) || pets[0];

  useEffect(() => {
    if (!selected) return;
    setLoadingMeals(true);
    api.getMeals(selected.id)
      .then(setMeals)
      .catch(() => setMeals([]))
      .finally(() => setLoadingMeals(false));
  }, [selected]);

  async function handleLogMeal(e) {
    e.preventDefault();
    if (!food.trim()) return showToast('Enter what your pet ate', 'error');
    try {
      const meal = await api.logMeal(selected.id, { food: food.trim(), amount: amount.trim() });
      setMeals((prev) => [meal, ...prev]);
      setFood('');
      setAmount('');
      showToast('Meal logged!', 'success');
    } catch (err) {
      showToast(err.message || 'Could not log meal', 'error');
    }
  }

  async function handleDeleteMeal(id) {
    try {
      await api.deleteMeal(id);
      setMeals((prev) => prev.filter((m) => m.id !== id));
    } catch (err) {
      showToast(err.message || 'Could not delete entry', 'error');
    }
  }

  if (!selected) {
    return (
      <div className="page">
        <div className="empty-state">
          <Activity size={40} />
          <h3>No pets to track yet</h3>
          <p>Add a pet first to start tracking their health and meals.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="page">
      <div className="page-header">
        <div>
          <h1>Health Tracking</h1>
          <p>Monitor wellness, vaccinations, and meals for your pets</p>
        </div>
      </div>

      <div className="pet-tab-row">
        {pets.map((p) => (
          <button
            key={p.id}
            className={`pet-tab${selected.id === p.id ? ' pet-tab-active' : ''}`}
            onClick={() => setSelectedId(p.id)}
          >
            {p.name}
          </button>
        ))}
      </div>

      <div className="health-grid">
        <div className="card">
          <h3><BadgeCheck size={18} /> Vaccination Status</h3>
          <div className={`health-banner ${selected.vaccinations_current ? 'health-good' : 'health-warn'}`}>
            <BadgeCheck size={18} />
            <div>
              <strong>{selected.vaccinations_current ? 'Up to Date' : 'Needs Attention'}</strong>
              {selected.next_vaccination && <small>Next due: {selected.next_vaccination}</small>}
            </div>
          </div>
          <h3 className="mt-lg"><Syringe size={18} /> Microchip</h3>
          <div className="microchip-banner">
            <Syringe size={18} />
            <div>
              <strong>{selected.microchip || 'Not registered'}</strong>
              <small>Registered identification</small>
            </div>
          </div>
          <h3 className="mt-lg"><Activity size={18} /> Vitals</h3>
          <ul className="detail-list">
            <li><div><small>Weight</small><strong>{selected.weight_kg || 0} kg</strong></div></li>
            <li><div><small>Age</small><strong>{selected.age_years || 0} years</strong></div></li>
          </ul>
        </div>

        <div className="card">
          <h3><Utensils size={18} /> Meal Log</h3>
          <form className="meal-form" onSubmit={handleLogMeal}>
            <input placeholder="What did they eat?" value={food} onChange={(e) => setFood(e.target.value)} />
            <input placeholder="Amount (optional)" value={amount} onChange={(e) => setAmount(e.target.value)} style={{ maxWidth: 140 }} />
            <button type="submit" className="btn btn-gradient"><Plus size={16} /> Log</button>
          </form>

          {loadingMeals ? (
            <p className="muted">Loading meals…</p>
          ) : meals.length === 0 ? (
            <p className="muted">No meals logged yet today.</p>
          ) : (
            <ul className="meal-list">
              {meals.map((m) => (
                <li key={m.id}>
                  <div>
                    <strong>{m.food}</strong>
                    {m.amount && <span className="muted"> — {m.amount}</span>}
                    <small className="block muted">{new Date(m.logged_at).toLocaleString()}</small>
                  </div>
                  <button className="icon-btn" onClick={() => handleDeleteMeal(m.id)} aria-label="Delete">
                    <Trash2 size={15} />
                  </button>
                </li>
              ))}
            </ul>
          )}
        </div>
      </div>
    </div>
  );
}
