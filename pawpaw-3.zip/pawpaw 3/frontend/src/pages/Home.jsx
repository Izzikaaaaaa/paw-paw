import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Award, Clock, ShieldCheck, Sparkles, PawPrint } from 'lucide-react';
import BookAppointmentModal from '../components/BookAppointmentModal';
import { useAppData } from '../context/AppDataContext';

const FEATURES = [
  { icon: Award, color: 'orange', title: 'Premium Care', text: 'Vetted, top-rated professionals for every service your pet needs.' },
  { icon: Clock, color: 'pink', title: '24/7 Support', text: 'Round-the-clock access to our care team and AI companion, Pawla.' },
  { icon: ShieldCheck, color: 'purple', title: 'Health Tracking', text: 'Keep vaccination records, weight, and wellness all in one place.' },
  { icon: Sparkles, color: 'magenta', title: 'Smart Insights', text: 'AI-powered suggestions tailored to your pet\u2019s breed and habits.' }
];

export default function Home() {
  const navigate = useNavigate();
  const { pets } = useAppData();
  const [bookOpen, setBookOpen] = useState(false);
  const heroPet = pets[0];

  return (
    <div className="page">
      <section className="hero">
        <div className="hero-text">
          <span className="pill pill-light"><PawPrint size={14} /> Premium Pet Care Service</span>
          <h1>
            Your Pet's Health &amp; <span className="gradient-text">Happiness Partner</span>
          </h1>
          <p className="hero-copy">
            Experience premium care with our AI-powered health monitoring, 24/7 expert support, and comprehensive
            wellness tracking for your beloved companions.
          </p>
          <div className="hero-actions">
            <button className="btn btn-gradient btn-lg" onClick={() => setBookOpen(true)}>Book Appointment</button>
            <button className="btn btn-outline btn-lg" onClick={() => navigate('/services')}>Learn More</button>
          </div>
        </div>

        <div className="hero-media">
          <div className="hero-image-card">
            <img
              src={heroPet?.photo || 'https://images.unsplash.com/photo-1529429617124-95b109e86bb8?w=600&q=80'}
              alt={heroPet?.name || 'Happy pet'}
            />
          </div>
          <div className="hero-stat-card">
            <span className="stat-icon"><Sparkles size={18} /></span>
            <div>
              <strong>2,500+</strong>
              <small>Happy Pets</small>
            </div>
          </div>
        </div>
      </section>

      <section className="feature-grid">
        {FEATURES.map((f) => (
          <div key={f.title} className="feature-card">
            <span className={`feature-icon feature-icon-${f.color}`}><f.icon size={22} /></span>
            <h3>{f.title}</h3>
            <p>{f.text}</p>
          </div>
        ))}
      </section>

      <section className="cta-banner">
        <div>
          <h2>Ready to give your pet the care they deserve?</h2>
          <p>Add their profile, book a service, or just chat with Pawla about anything on your mind.</p>
        </div>
        <div className="cta-actions">
          <button className="btn btn-gradient" onClick={() => navigate('/pets')}>Add My Pet</button>
          <button className="btn btn-outline" onClick={() => navigate('/services')}>Browse Services</button>
        </div>
      </section>

      <BookAppointmentModal open={bookOpen} onClose={() => setBookOpen(false)} />
    </div>
  );
}
